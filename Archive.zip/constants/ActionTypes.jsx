export const NEXT_ACTION = 'NEXT_ACTION'
